__authors__ = 'TO_BE_FILLED'
__group__ = 'TO_BE_FILLED'

from utils_data import read_dataset, read_extended_dataset, crop_images
import numpy as np
import utils


class KMeans:

    def __init__(self, X, K=1, options=None):
        """
         Constructor of KMeans class
             Args:
                 K (int): Number of cluster
                 options (dict): dictionary with options
            """
        self.num_iter = 0
        self.K = K
        self._init_X(X)
        self._init_options(options)  # DICT options

    #############################################################
    ##  THIS FUNCTION CAN BE MODIFIED FROM THIS POINT, if needed
    #############################################################

    def _init_X(self, X):
        """
        Ensures that X is a float-type matrix with dimensions N × D.
        If the input is an image of dimensions F × C × 3, it reshapes it to (N × 3).
        """
        X = np.array(X, dtype=np.float32)  # (a) Ensure float type

        if len(X.shape) > 2 and X.shape[-1] == 3:
            X = X.reshape(-1, 3)

        self.X = X

    def _init_options(self, options=None):
        """
        Initialization of options in case some fields are left undefined
        Args:
            options (dict): dictionary with options
        """
        if options is None:
            options = {}
        if 'km_init' not in options:
            options['km_init'] = 'first'
        if 'verbose' not in options:
            options['verbose'] = False
        if 'tolerance' not in options:
            options['tolerance'] = 0
        if 'max_iter' not in options:
            options['max_iter'] = np.inf
        if 'fitting' not in options:
            options['fitting'] = 'WCD'  # within class distance.

        # If your methods need any other parameter you can add it to the options dictionary
        self.options = options

        #############################################################
        ##  THIS FUNCTION CAN BE MODIFIED FROM THIS POINT, if needed
        #############################################################

    def _init_centroids(self):
        """
        Initializes centroids based on the selected initialization method.
        The available methods are:
        - 'first': Uses the first K distinct points from X.
        - 'random': Selects K unique random points from X.
        """
        self.old_centroids = np.zeros((self.K, self.X.shape[1]))

        if self.options['km_init'].lower() == 'first':
            # Select the first K distinct points
            seen = set()
            centroids = []
            for point in self.X:
                tuple_point = tuple(point)
                if tuple_point not in seen:
                    seen.add(tuple_point)
                    centroids.append(point)
                if len(centroids) == self.K:
                    break

            if len(centroids) < self.K:
                raise ValueError("Not enough unique points to initialize K distinct centroids.")

            self.centroids = np.array(centroids, dtype=np.float32)

        elif self.options['km_init'].lower() == 'random':
            # Select K unique random points as centroids
            indices = np.random.choice(self.X.shape[0], self.K, replace=False)
            self.centroids = self.X[indices].astype(np.float32)

        else:
            raise ValueError("Invalid initialization method. Choose 'first' or 'random'.")

    def get_labels(self):
        """
        Calculates the closest centroid of all points in X and assigns each point to the closest centroid
        """
        distances = distance(self.X, self.centroids)
        self.labels = np.argmin(distances, axis=1)

    def get_centroids(self):
        """
        Updates the centroids by computing the mean of all points assigned to each centroid.
        """
        self.old_centroids = self.centroids.copy()

        new_centroids = np.zeros_like(self.centroids, dtype=np.float64)
        for k in range(self.K):
            points = self.X[self.labels == k]
            if len(points) > 0:
                new_centroids[k] = np.mean(points, axis=0, dtype=np.float64)

        self.centroids = new_centroids.astype(np.float64)

    def converges(self):
        """
        Checks if the centroids have converged by comparing current and previous centroids.
        Returns True if the maximum change in any centroid is less than the tolerance threshold,
        False otherwise.
        """
        if self.num_iter >= self.options['max_iter']:
            return True

        if not hasattr(self, 'old_centroids'):
            return False

        distances = np.linalg.norm(self.centroids - self.old_centroids, axis=1)
        return np.all(distances <= self.options['tolerance']) and self.num_iter <= self.options['max_iter']

    def fit(self):
        """
        Runs K-Means algorithm until it converges or until reaching maximum iterations.
        The steps are:
        1. Initialize centroids
        2. Repeat until convergence:
            a. Assign points to nearest centroids (get_labels)
            b. Update centroids (get_centroids)
            c. Check convergence
        """
        # Initialize centroids
        self._init_centroids()
        self.num_iter = 0

        while True:
            self.get_labels()
            self.get_centroids()
            self.num_iter += 1

            # Check for convergence
            if self.converges():
                break

            # Print progress if verbose mode is enabled
            if self.options['verbose'] and self.num_iter % 10 == 0:
                print(f"Iteration {self.num_iter}, Current WCD: {self.withinClassDistance()}")

        # Final WCD calculation
        self.withinClassDistance()

        if self.options['verbose']:
            print(f"Converged after {self.num_iter} iterations")
            print(f"Final WCD: {self.WCD}")

    def withinClassDistance(self):
        """
         returns the within class distance of the current clustering
        """

        if not hasattr(self, 'labels') or len(self.labels) == 0:
            return 0.0

        assigned_centroids = self.centroids[self.labels]

        squared_distances = np.sum((self.X - assigned_centroids) ** 2, axis=1)

        self.WCD = np.mean(squared_distances)

        return self.WCD

    def find_bestK(self, max_K, threshold=10):
        """
        Finds the optimal number of clusters by analyzing WCD improvement rates.
        Returns the K where WCD improvement drops below threshold.
        If no such K is found, returns max_K.

        Args:
            max_K (int): Maximum number of clusters to try
            threshold (float): Improvement percentage threshold (default 20%)

        Returns:
            int: Optimal number of clusters found
        """
        if max_K < 2:
            return max_K

        original_K = self.K
        wcd_values = []
        best_k = max_K  # Default to max_K if no better k is found

        for k in range(2, max_K + 1):
            self.K = k
            self.fit()
            current_wcd = self.withinClassDistance()
            wcd_values.append(current_wcd)

            # Start checking improvements from K=3 onward
            if k >= 3:
                # Calculate percentage improvement
                improvement = 100 * (wcd_values[-2] - wcd_values[-1]) / wcd_values[-2]

                # If improvement drops below threshold, select previous K
                if improvement < threshold:
                    best_k = k - 1
                    break

        self.K = best_k  # Update to best found K
        return best_k

    def inter_class_distance(self):
        """
        Computes average pairwise distance between centroids (Inter-Class Distance)
        """
        if self.centroids.shape[0] < 2:
            return 0.0

        dists = []
        for i in range(self.K):
            for j in range(i + 1, self.K):
                dists.append(np.linalg.norm(self.centroids[i] - self.centroids[j]))

        return np.mean(dists)

    def fisher_score(self):
        """
        Computes the Fisher criterion (Inter-Class Distance / Within-Class Distance)
        """
        icd = self.inter_class_distance()
        wcd = self.withinClassDistance()
        return wcd / (icd + 1e-8)  # adding to avoid division by zero

    def find_bestK_by_heuristic(self, max_K=10, method='fisher', verbose=False):
        """
        Tries values of K from 2 to max_K and selects the best one based on the given heuristic.

        Args:
            max_K (int): Max number of clusters to try
            method (str): 'fisher', 'inter_class', or 'wcd'
            verbose (bool): If True, print scores for each K

        Returns:
            int: Best K based on selected heuristic
        """
        original_K = self.K
        best_K = 2
        best_score = np.inf if method == 'wcd' else -np.inf
        scores = {'K': [], 'WCD': [], 'ICD': [], 'Fisher': []}

        for k in range(2, max_K + 1):
            self.K = k
            self.fit()

            wcd = self.withinClassDistance()
            icd = self.inter_class_distance()
            fisher = icd / (wcd + 1e-8)

            scores['K'].append(k)
            scores['WCD'].append(wcd)
            scores['ICD'].append(icd)
            scores['Fisher'].append(fisher)

            if method == 'wcd':
                if wcd < best_score:
                    best_score = wcd
                    best_K = k
            elif method == 'inter_class':
                if icd > best_score:
                    best_score = icd
                    best_K = k
            elif method == 'fisher':
                if fisher > best_score:
                    best_score = fisher
                    best_K = k
            else:
                raise ValueError("Unknown method. Use 'fisher', 'inter_class', or 'wcd'.")

            if verbose:
                print(f"K = {k}: WCD = {wcd:.2f}, ICD = {icd:.2f}, Fisher = {fisher:.4f}")

        self.K = best_K
        if verbose:
            print(f"Best K = {best_K} based on '{method}' heuristic.")
        return best_K


def distance(X, C):
    """
    Calculates the distance between each pixel and each centroid
    Args:
        X (numpy array): PxD 1st set of data points (usually data points)
        C (numpy array): KxD 2nd set of data points (usually cluster centroids points)

    Returns:
        dist: PxK numpy array position ij is the distance between the
        i-th point of the first set an the j-th point of the second set
    """

    return np.linalg.norm(X[:, np.newaxis] - C, axis=2)


def get_colors(centroids):
    """
    Assigns color labels to centroids based on probability scores from get_color_prob.

    Args:
        centroids (numpy array): KxD array of centroid colors in RGB space

    Returns:
        list: Color labels corresponding to each centroid
    """
    color_probs = utils.get_color_prob(centroids)

    color_indices = np.argmax(color_probs, axis=1)

    return [utils.colors[idx] for idx in color_indices]
